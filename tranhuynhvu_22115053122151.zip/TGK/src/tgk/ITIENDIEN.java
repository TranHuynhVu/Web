package tgk;

public interface ITIENDIEN {
	public double tinhThanhTien();
}
