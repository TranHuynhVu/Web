package tgk;
import java.util.Date;
import java.util.Scanner;

public class KHACHHANGNUOCNGOAI extends KHACHHANG{
	private String quocTich;
	
	
	public KHACHHANGNUOCNGOAI(String maKhachHang, String hoTen, Date ngayRaHoaDon, int soLuong, double donGia,
			String quocTich) {
		super(maKhachHang, hoTen, ngayRaHoaDon, soLuong, donGia);
		this.quocTich = quocTich;
	}

	public KHACHHANGNUOCNGOAI() {
		super();
	}

	public String getQuocTich() {
		return quocTich;
	}

	public void setQuocTich(String quocTich) {
		this.quocTich = quocTich;
	}
	
	public void nhap() {
		Scanner rc = new Scanner(System.in);
		super.nhap();
		System.out.println("Quoc Tich: ");
		this.quocTich = rc.nextLine();
	}

	@Override
	public String toString() {
		return super.toString()+"| Quoc Tich: "+this.getQuocTich();
	}

	@Override
	public double tinhThanhTien() {
		return soLuong * donGia;
	}
	
}
