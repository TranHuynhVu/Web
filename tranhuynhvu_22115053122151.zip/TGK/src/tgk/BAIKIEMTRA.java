package tgk;

import java.util.Scanner;

public class BAIKIEMTRA {
	public static void main(String[] args) {
		DSKHACHHANG dskhachhang = new DSKHACHHANG();
		boolean run = true;
		int kt,n;
		Scanner rc = new Scanner(System.in);
		while(run) {
			System.out.println("*************************");
			System.out.println("* 1.Them Moi khach Hang *");
			System.out.println("* 2.Xoa Khach Hang      *");
			System.out.println("* 3.Cap nhat            *");
			System.out.println("* 4.Tim Kiem            *");
			System.out.println("* 5.Hien Thi            *");
			System.out.println("* 6.Hien thi thanh tien *");
			System.out.println("* 7.Hien thi so luong   *");
			System.out.println("* 8.Thoat               *");
			System.out.println("*************************");
			kt = rc.nextInt();
			rc.nextLine();
			switch(kt) {
			case 1:	System.out.println("Nhap vao so luong Khach Hang: ");
					n = rc.nextInt();
					for(int i = 0; i < n; i++) {
						System.out.println("Khach Hang "+(i+1));
						dskhachhang.themMoi();
					}
					break;
			case 2:	System.out.println("Nhap maKhachHang can xoa: ");
			 		String maKhachHangXoa;
			 		maKhachHangXoa = rc.nextLine();
			 		dskhachhang.xoa(maKhachHangXoa);
					break;
			case 3:	System.out.println("Nhap maKhachHang can cap nhat: ");
	 				String maKhachHangCapNhat;
	 				maKhachHangCapNhat = rc.nextLine();
	 				dskhachhang.capnhat(maKhachHangCapNhat);
					break;
			case 4:	System.out.println("Nhap maKhachHang can tim: ");
					String maKhachHangtimKiem;
					maKhachHangtimKiem = rc.nextLine();
					dskhachhang.timKiem(maKhachHangtimKiem);
					break;	
				
			case 5:	dskhachhang.hienThiKhachHang();
					break;
			case 6: System.out.println("Thanh Tien Khach Hang Viet Nam: "+dskhachhang.tongVN());
					System.out.println("Thanh Tien Khach Hang Viet Nam: "+dskhachhang.tongNN());
					break;
			case 7: System.out.println("So Luong Khach Hang Viet Nam: "+dskhachhang.slVN());
					System.out.println("So Luong Khach Hang Viet Nam: "+dskhachhang.slNN());
					break;
			case 8: run = false;
					break;
			}
		}
	
	}
}
