package tgk;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Scanner;

public abstract class KHACHHANG implements ITIENDIEN{
	protected String maKhachHang;
	protected String hoTen;
	protected Date ngayRaHoaDon;
	protected int soLuong;
	protected double donGia;
	
	public KHACHHANG(String maKhachHang, String hoTen, Date ngayRaHoaDon, int soLuong, double donGia) {
		super();
		this.maKhachHang = maKhachHang;
		this.hoTen = hoTen;
		this.ngayRaHoaDon = ngayRaHoaDon;
		this.soLuong = soLuong;
		this.donGia = donGia;
	}

	public KHACHHANG() {
		super();
	}

	public String getMaKhachHang() {
		return maKhachHang;
	}

	public void setMaKhachHang(String maKhachHang) {
		this.maKhachHang = maKhachHang;
	}

	public String getHoTen() {
		return hoTen;
	}

	public void setHoTen(String hoTen) {
		this.hoTen = hoTen;
	}

	public Date getNgayRaHoaDon() {
		return ngayRaHoaDon;
	}

	public void setNgayRaHoaDon(Date ngayRaHoaDon) {
		this.ngayRaHoaDon = ngayRaHoaDon;
	}

	public int getSoLuong() {
		return soLuong;
	}

	public void setSoLuong(int soLuong) {
		this.soLuong = soLuong;
	}

	public double getDonGia() {
		return donGia;
	}

	public void setDonGia(double donGia) {
		this.donGia = donGia;
	}
	
	public void nhap() {
		Scanner rc = new Scanner(System.in);
		System.out.println("Ma Kach Hang: ");
		this.maKhachHang = rc.nextLine();
		System.out.println("Ho Ten: ");
		this.hoTen = rc.nextLine();
		System.out.println("Ngay Ra Hoa Don");
		try {
			SimpleDateFormat d = new SimpleDateFormat("dd/MM/yyyy");
			this.ngayRaHoaDon = d.parse(rc.nextLine());
		} catch (Exception e) {		
		}
		System.out.println("So Luong: ");
		this.soLuong = rc.nextInt();
		System.out.println("Don Gia: ");
		this.donGia = rc.nextDouble();
	}

	@Override
	public String toString() {
		SimpleDateFormat d = new SimpleDateFormat("dd/MM/yyyy");
		return ("Ma Khach Hang: "+ this.getMaKhachHang()+"| Ho Ten: "+this.getHoTen()+"| Ngay Ra Hoa Don: "+d.format(this.getNgayRaHoaDon())+"| So Luong: "+this.getSoLuong()+"| Don Gia: "+this.getDonGia());
	}
	
	
}
