package tgk;

import java.util.ArrayList;
import java.util.Scanner;

public class DSKHACHHANG {
	public ArrayList<KHACHHANG> DS;
	Scanner rc = new Scanner(System.in);
	public DSKHACHHANG() {
		DS = new ArrayList<KHACHHANG>();	
	}
	
	public void themMoi() {
		int key;
		System.out.println("****************************");
		System.out.println("* 1. Khach Hang Viet Nam   *");
		System.out.println("* 2. Khach Hang Nuoc Ngoai *");
		System.out.println("****************************");
		key = rc.nextInt();
		if(key == 1) {
			KHACHHANGVIETNAM vn = new KHACHHANGVIETNAM();
			vn.nhap();
			DS.add(vn);
		}else {
			KHACHHANGNUOCNGOAI nn = new KHACHHANGNUOCNGOAI();
			nn.nhap();
			DS.add(nn);
		}
	}
	
	public void hienThiKhachHang() {
		for (KHACHHANG khachhang : DS) {
			System.out.println(khachhang);
		}
	}
	
	public void xoa(String maKhachHang) {
		for(int i = 0; i < DS.size(); i++) {
			if(DS.get(i).maKhachHang.equals(maKhachHang)) {
				DS.remove(i);
			}
		}
	}
	
	public void capnhat(String maKhachHang) {
		for(int i = 0; i < DS.size(); i++) {
			if(DS.get(i).maKhachHang.equals(maKhachHang)) {
				DS.get(i).nhap();
			}
		}
	}
	public void timKiem(String maKhachHang) {
		for(int i = 0; i < DS.size(); i++) {
			if(DS.get(i).maKhachHang.equals(maKhachHang)) {
				System.out.println(DS.get(i).toString());
			}
		}
	}
	public double tongVN() {
		double tong = 0;
		for(int i = 0; i < DS.size(); i++) {
			if(DS.get(i) instanceof KHACHHANGVIETNAM) {
				tong += DS.get(i).tinhThanhTien();
			}
		}
		return tong;
	}
	public double tongNN() {
		double tong = 0;
		for(int i = 0; i < DS.size(); i++) {
			if(DS.get(i) instanceof KHACHHANGNUOCNGOAI) {
				tong += DS.get(i).tinhThanhTien();
			}
		}
		return tong;
	}
	public double slVN() {
		double tong = 0;
		for(int i = 0; i < DS.size(); i++) {
			if(DS.get(i) instanceof KHACHHANGVIETNAM) {
				tong += DS.get(i).getSoLuong();
			}
		}
		return tong;
	}
	public double slNN() {
		double tong = 0;
		for(int i = 0; i < DS.size(); i++) {
			if(DS.get(i) instanceof KHACHHANGNUOCNGOAI) {
				tong += DS.get(i).getSoLuong();
			}
		}
		return tong;
	}
}
