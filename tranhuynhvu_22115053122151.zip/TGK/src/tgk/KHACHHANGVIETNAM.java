package tgk;
import java.util.Date;
import java.util.Scanner;

public class KHACHHANGVIETNAM extends KHACHHANG{
	private String doiTuongKhachHang;
	private double soLuongKw;
	private double dinhMuc;
	
	public KHACHHANGVIETNAM(String maKhachHang, String hoTen, Date ngayRaHoaDon, int soLuong, double donGia,
			String doiTuongKhachHang, double soLuongKw, double dinhMuc) {
		super(maKhachHang, hoTen, ngayRaHoaDon, soLuong, donGia);
		this.doiTuongKhachHang = doiTuongKhachHang;
		this.soLuongKw = soLuongKw;
		this.dinhMuc = dinhMuc;
	}


	public KHACHHANGVIETNAM() {
		super();
	}

	public double getSoLuongKw() {
		return soLuongKw;
	}


	public void setSoLuongKw(double soLuongKw) {
		this.soLuongKw = soLuongKw;
	}


	public String getDoiTuongKhachHang() {
		return doiTuongKhachHang;
	}


	public void setDoiTuongKhachHang(String doiTuongKhachHang) {
		this.doiTuongKhachHang = doiTuongKhachHang;
	}


	public double getDinhMuc() {
		return dinhMuc;
	}


	public void setDinhMuc(double dinhMuc) {
		this.dinhMuc = dinhMuc;
	}

	
	@Override
	public double tinhThanhTien() {
		if(this.soLuong <= this.dinhMuc)
			return soLuong * donGia;
		else {
			return soLuong * donGia * dinhMuc + soLuongKw * donGia *2.5;
		}
	}
	
	public void nhap() {
		Scanner rc = new Scanner(System.in);
		super.nhap();
		System.out.println("Doi Tuong Khach Hang: ");
		this.doiTuongKhachHang =rc.nextLine();
		System.out.println("Dinh Muc: ");
		this.dinhMuc = rc.nextDouble();
		System.out.println("So Luong KW: ");
		this.soLuongKw = rc.nextDouble();
		
	}


	@Override
	public String toString() {
		return super.toString()+"| Doi Tuong Khach Hang: "+this.getDoiTuongKhachHang()+"| Dinh Muc: "+this.getDinhMuc();
	}
	

}
